package ie.cit.caf.lctutorial3.domain;

public class Time {
	
	private int startYear;

	public int getStartYear() {
		return startYear;
	}

	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}
}

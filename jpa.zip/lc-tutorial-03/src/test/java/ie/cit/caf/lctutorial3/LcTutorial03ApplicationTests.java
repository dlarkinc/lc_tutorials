package ie.cit.caf.lctutorial3;

import ie.cit.caf.lctutorial3.JdbcTemplateTestApplication;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = JdbcTemplateTestApplication.class)
public class LcTutorial03ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
